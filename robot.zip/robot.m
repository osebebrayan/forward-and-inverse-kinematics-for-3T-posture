%created by osebe brayan
%the code corresponds to the paper i have provided%the code solves the acceleration velocity and position of the end effactor

% Known values
L2 =200; % mm
L3 = 75; % mm
L5 =203; % mm
%for L1 ANDL2 use a constant value of alpha1 to calculate the lenghts
alpha1=45;
%known parameter using equations
L1 =L5*cos(alpha1)-L2;%input link
L4 = L1*sin(alpha1)-L3;%output link 

% Initial guesses for alpha1 and alpha2
alpha1_guess = 90;
alpha2_guess = 120;

% Convergence criteria
tolerance = 1e-6;
max_iterations = 100;

% Iterative solver using Newton-Raphson method
for i = 1:max_iterations
    % Calculate the function values and Jacobian matrix
    F = @(alpha1, alpha2) [L3*cos(alpha2) + L5 - L1*cos(alpha1) + L4*cos(alpha2) - L2*cos(alpha1); 
                           L3*sin(alpha2) - L1*sin(alpha1) + L4*sin(alpha2) + L2*sin(alpha1)];
    J = @(alpha1, alpha2) [L1*sin(alpha1)+L2*sin(alpha1), -L4*sin(alpha2)-L3*sin(alpha2); 
                            L1*cos(alpha1)+L2*cos(alpha1),  L4*cos(alpha2)+L3*cos(alpha2)];

    % Evaluate function and Jacobian at current guess
    f = F(alpha1_guess, alpha2_guess);
    J_eval = J(alpha1_guess, alpha2_guess);
    
    % Update guess using Newton-Raphson formula
    delta = -(J_eval\f);
    alpha1_new = alpha1_guess + delta(1);
    alpha2_new = alpha2_guess + delta(2);

   
    % Check for convergence
    if norm(delta)>tolerance
        disp('converged')
        break;
    end
end 

% Output results
alpha1 = alpha1_new;
alpha2 = alpha2_new;

disp(['alpha1: ', num2str(alpha1)]);
disp(['alpha2: ', num2str(alpha2)]);

% Initial guesses for omega1 and omega2
omega1_guess = 30;
omega2_guess = 20;
% Iterative solver using Newton-Raphson method
for i = 1:max_iterations
    % Define objective function
    fun = @(omega1, omega2) [(-L3*omega2*sin(alpha2)) - L4*omega2*sin(alpha2_guess) + L1*omega1*sin(alpha1) + L2*omega1*sin(alpha1); 
                              L3*omega2*cos(alpha2) + L4*omega2*cos(alpha2) - L1*omega1*cos(alpha1) - L2*omega1*cos(alpha1)];
    J_fun= @(omega1, omega2) [(-L3*sin(alpha2)) - L4*sin(alpha2), L1*sin(alpha1) + L2*sin(alpha1);
                           L3*cos(alpha2) + L4*cos(alpha2), -L1*cos(alpha1) - L2*cos(alpha1)];

    % Evaluate function and Jacobian at current guess
    f_eval = fun(omega1_guess, omega2_guess);
    J_eva = J_fun(omega1_guess, omega2_guess);
    
  
    % Update guess using Newton-Raphson formula
    delta = -(J_eva\f_eval);
    omega1_new = omega1_guess + delta(1);
    omega2_new= omega2_guess + delta(2);

    % Check for convergence
    if norm(delta) > tolerance
        disp('Converged!');
        break;
    end
end 

% Output results
omega1 = omega1_new;
omega2 = omega2_new;

disp(['omega1 in rads/s: ', num2str(omega1)]);
disp(['omega2in rads/s: ', num2str(omega2)]);

%accelaration
% Initial guesses for alphadot
alphadot_guess=1;%in rads/s^2

% Convergence criteria
tolerance = 1e-6;
max_iterations = 100;

% Iterative solver using Newton-Raphson method
for i = 1:max_iterations
     % Calculate the function values and Jacobian matrix
Fa=@(alphadot)[((L3+L4)*alphadot*sin(alpha2))+((L3+L4)*alphadot*cos(alpha2))+((L3+L4)*(omega2^2)*cos(alpha2))-((L3+L4)*(omega2^2)*sin(alpha2))-((L3+L4)*(omega1^2)*cos(alpha2))+((L3+L4)*(omega1^2)*sin(alpha1))];
dFa=((L3+L4)*sin(alpha2))+((L3+L4)*cos(alpha2));
 %Evaluate function at current guess
    f_eva = Fa(alphadot_guess);
    
    % Update guess using Newton-Raphson formula
    delta = f_eva/dFa;
    alphadot_new = alphadot_guess + delta;

    % Check for convergence
    if abs(delta) > tolerance
        disp('Converged!');
        break;
    end
end 

% Output result
alphadot = alphadot_new;

disp(['alphadot: ', num2str(alphadot)]);


